import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Loader2, Heart, Share2 } from "lucide-react";
import { toast } from "sonner";

interface CardData {
  id: string;
  name: string;
  cardCode: string;
  rarity?: string;
  setName?: string;
  imageUrl?: string;
  marketPrice?: number;
  lowPrice?: number;
  highPrice?: number;
  midPrice?: number;
  suggestedSellingPrice?: number;
}

export default function CardDetail() {
  const { user } = useAuth();
  const [location, setLocation] = useLocation();
  const [cardData, setCardData] = useState<CardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  // Get cardId from URL query params
  const params = new URLSearchParams(window.location.search);
  const cardId = params.get("cardId");

  useEffect(() => {
    const fetchCardData = async () => {
      if (!cardId) {
        toast.error("ID carta non valido");
        setLocation("/");
        return;
      }

      try {
        setIsLoading(true);
        // This would be replaced with actual API call
        // For now, we'll show a placeholder
        setCardData({
          id: cardId,
          name: "Caricamento...",
          cardCode: "Loading",
          rarity: "Unknown",
        });
      } catch (error) {
        console.error("Error fetching card:", error);
        toast.error("Errore nel caricamento della carta");
      } finally {
        setIsLoading(false);
      }
    };

    fetchCardData();
  }, [cardId, setLocation]);

  const handleSaveCard = async () => {
    if (!cardData || !user) return;

    try {
      setIsSaving(true);
      // Call backend to save card
      const response = await fetch("/api/trpc/cards.saveCard", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          cardId: cardData.id,
          cardName: cardData.name,
          cardCode: cardData.cardCode,
          rarity: cardData.rarity,
          setName: cardData.setName,
          imageUrl: cardData.imageUrl,
          marketPrice: cardData.marketPrice,
          lowPrice: cardData.lowPrice,
          highPrice: cardData.highPrice,
          midPrice: cardData.midPrice,
          suggestedSellingPrice: cardData.suggestedSellingPrice,
        }),
      });

      if (!response.ok) {
        throw new Error("Errore nel salvataggio");
      }

      setIsSaved(true);
      toast.success("Carta salvata nello storico!");
    } catch (error) {
      console.error("Save error:", error);
      toast.error("Errore nel salvataggio della carta");
    } finally {
      setIsSaving(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <p className="text-center text-gray-600">Effettua il login per visualizzare i dettagli.</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!cardData) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <p className="text-center text-gray-600 mb-4">Carta non trovata</p>
        <Button onClick={() => setLocation("/")} variant="outline">
          Torna alla Home
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button
            onClick={() => setLocation("/scan")}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Dettagli Carta</h1>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col p-4 max-w-md mx-auto w-full py-6">
        {/* Card Image */}
        {cardData.imageUrl && (
          <div className="mb-6 rounded-lg overflow-hidden bg-white border border-slate-200 shadow-sm">
            <img
              src={cardData.imageUrl}
              alt={cardData.name}
              className="w-full h-auto object-cover"
            />
          </div>
        )}

        {/* Card Info */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">{cardData.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-slate-600 mb-1">Codice Carta</p>
                <p className="font-semibold text-slate-900">{cardData.cardCode}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600 mb-1">Rarità</p>
                <p className="font-semibold text-slate-900">{cardData.rarity || "N/A"}</p>
              </div>
            </div>
            {cardData.setName && (
              <div>
                <p className="text-xs text-slate-600 mb-1">Set</p>
                <p className="text-slate-900">{cardData.setName}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Price Information */}
        <Card className="mb-6 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-lg text-blue-900">Valutazione di Mercato</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {cardData.marketPrice && (
              <div className="bg-white rounded-lg p-3 border border-blue-100">
                <p className="text-xs text-slate-600 mb-1">Prezzo di Mercato</p>
                <p className="text-3xl font-bold text-blue-600">${cardData.marketPrice.toFixed(2)}</p>
              </div>
            )}

            <div className="grid grid-cols-3 gap-2">
              {cardData.lowPrice && (
                <div className="bg-white rounded-lg p-3 border border-blue-100">
                  <p className="text-xs text-slate-600 mb-1">Min</p>
                  <p className="font-semibold text-slate-900">${cardData.lowPrice.toFixed(2)}</p>
                </div>
              )}
              {cardData.midPrice && (
                <div className="bg-white rounded-lg p-3 border border-blue-100">
                  <p className="text-xs text-slate-600 mb-1">Medio</p>
                  <p className="font-semibold text-slate-900">${cardData.midPrice.toFixed(2)}</p>
                </div>
              )}
              {cardData.highPrice && (
                <div className="bg-white rounded-lg p-3 border border-blue-100">
                  <p className="text-xs text-slate-600 mb-1">Max</p>
                  <p className="font-semibold text-slate-900">${cardData.highPrice.toFixed(2)}</p>
                </div>
              )}
            </div>

            {cardData.suggestedSellingPrice && (
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-200">
                <p className="text-xs text-green-700 mb-1 font-semibold">PREZZO CONSIGLIATO PER VENDITA</p>
                <p className="text-2xl font-bold text-green-700">${cardData.suggestedSellingPrice.toFixed(2)}</p>
                <p className="text-xs text-green-600 mt-2">Basato sui trend di mercato attuali</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3 mb-6">
          <Button
            onClick={handleSaveCard}
            disabled={isSaving || isSaved}
            size="lg"
            className="w-full gap-2 bg-blue-600 hover:bg-blue-700"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Salvataggio...
              </>
            ) : isSaved ? (
              <>
                <Heart className="w-4 h-4 fill-current" />
                Salvata
              </>
            ) : (
              <>
                <Heart className="w-4 h-4" />
                Salva nello Storico
              </>
            )}
          </Button>

          <Button
            variant="outline"
            size="lg"
            className="w-full gap-2"
          >
            <Share2 className="w-4 h-4" />
            Condividi
          </Button>
        </div>

        {/* Info */}
        <div className="bg-slate-100 rounded-lg p-4 text-xs text-slate-700">
          <p>Prezzi forniti da <strong>TCGPlayer</strong> in USD. Aggiornati in tempo reale.</p>
        </div>
      </div>
    </div>
  );
}
