import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { CameraScanner } from "@/components/CameraScanner";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export default function Scan() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<Blob | null>(null);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <p className="text-center text-gray-600">Effettua il login per scansionare carte.</p>
      </div>
    );
  }

  const handleCapture = async (imageBlob: Blob) => {
    try {
      setIsProcessing(true);
      setCapturedImage(imageBlob);

      // Convert blob to base64 for API transmission
      const reader = new FileReader();
      reader.readAsDataURL(imageBlob);

      reader.onload = async () => {
        const base64Image = reader.result as string;

        try {
          // Call backend to recognize card using Gemini Vision
          const response = await fetch("/api/trpc/cards.recognizeCard", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              image: base64Image,
            }),
          });

          if (!response.ok) {
            throw new Error("Errore nel riconoscimento della carta");
          }

          const data = await response.json();

          if (data.result) {
            // Redirect to card details with the recognized card data
            setLocation(`/card-detail?cardId=${data.result.cardId}`);
          } else {
            toast.error("Carta non riconosciuta. Riprova con un'immagine più chiara.");
            setCapturedImage(null);
          }
        } catch (error) {
          console.error("Recognition error:", error);
          toast.error("Errore nel riconoscimento della carta. Riprova.");
          setCapturedImage(null);
        }
      };
    } catch (error) {
      console.error("Capture error:", error);
      toast.error("Errore nella cattura dell'immagine. Riprova.");
      setCapturedImage(null);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-slate-900">Scansiona Carta</h1>
          <p className="text-sm text-slate-600 mt-1">Inquadra una carta Pokémon con la fotocamera</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col p-4 max-w-md mx-auto w-full">
        <div className="mt-4">
          <CameraScanner onCapture={handleCapture} isProcessing={isProcessing} />
        </div>

        {/* Tips */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-semibold text-blue-900 text-sm mb-2">Consigli per una scansione migliore:</h3>
          <ul className="text-xs text-blue-800 space-y-1">
            <li>✓ Assicurati che la carta sia ben illuminata</li>
            <li>✓ Posiziona la carta al centro del riquadro</li>
            <li>✓ Mantieni la fotocamera stabile</li>
            <li>✓ Evita riflessi sulla carta</li>
          </ul>
        </div>

        {/* Processing Indicator */}
        {isProcessing && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 flex flex-col items-center gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
              <p className="text-sm font-medium text-slate-900">Riconoscimento carta in corso...</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
