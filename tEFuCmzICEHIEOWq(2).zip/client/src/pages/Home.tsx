import React, { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Camera, History, LogOut } from "lucide-react";
import { getLoginUrl } from "@/const";

// Particle animation component
function ParticleBackground() {
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;
      color: string;
    }> = [];

    // Create particles
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.5,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        opacity: Math.random() * 0.5 + 0.3,
        color: Math.random() > 0.5 ? "#fbbf24" : "#06b6d4",
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;

        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.opacity;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      ctx.globalAlpha = 1;
      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none"
    />
  );
}

export default function Home() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [isHovering, setIsHovering] = useState(false);

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  if (!user) {
    return (
      <div className="min-h-screen relative overflow-hidden">
        {/* Background with Pokemon sparkle effect */}
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage:
              "url('https://private-us-east-1.manuscdn.com/sessionFile/W4oNi9bUr7vrHe7xFDd2hQ/sandbox/nrq0FCB3BNJvUWT41UP5XD-img-1_1771185526000_na1fn_cG9rZW1vbi1zcGFya2xlLWJnLWhvbWU.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        >
          <ParticleBackground />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4">
          {/* Logo/Header */}
          <div className="text-center mb-12 animate-pulse">
            <img
              src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663354566707/zzikNLpXwcKjiPKc.png"
              alt="Poke Card Scanner"
              className="w-32 h-32 mx-auto mb-4 drop-shadow-lg"
            />
            <h1 className="text-5xl font-bold text-yellow-300 mb-2 drop-shadow-lg text-glow">
              Poke Card Scanner
            </h1>
            <p className="text-yellow-200 text-lg drop-shadow-md">
              Valuta le tue carte Pokémon istantaneamente
            </p>
          </div>

          {/* Features */}
          <div className="w-full max-w-sm space-y-4 mb-12">
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4 text-white border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <div className="flex gap-3 mb-2">
                <Camera className="w-5 h-5 flex-shrink-0 text-yellow-300" />
                <div>
                  <h3 className="font-semibold text-yellow-300">
                    Scansiona Istantaneamente
                  </h3>
                  <p className="text-sm text-yellow-100">
                    Usa la fotocamera per identificare le carte
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4 text-white border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <div className="flex gap-3 mb-2">
                <div className="w-5 h-5 flex-shrink-0 text-yellow-300">💰</div>
                <div>
                  <h3 className="font-semibold text-yellow-300">
                    Prezzi in Tempo Reale
                  </h3>
                  <p className="text-sm text-yellow-100">
                    Valori di mercato aggiornati da TCGPlayer
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4 text-white border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <div className="flex gap-3 mb-2">
                <History className="w-5 h-5 flex-shrink-0 text-yellow-300" />
                <div>
                  <h3 className="font-semibold text-yellow-300">
                    Storico Personale
                  </h3>
                  <p className="text-sm text-yellow-100">
                    Salva e traccia tutte le tue scansioni
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Login Button */}
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            size="lg"
            className="w-full max-w-sm bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-semibold shadow-lg transform hover:scale-105 transition-all duration-300"
          >
            Accedi per Iniziare
          </Button>

          {/* Footer */}
          <p className="text-yellow-200 text-xs mt-8 text-center drop-shadow-md">
            Powered by Pokémon TCG API
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col relative"
      style={{
        backgroundImage:
          "url('https://private-us-east-1.manuscdn.com/sessionFile/W4oNi9bUr7vrHe7xFDd2hQ/sandbox/nrq0FCB3BNJvUWT41UP5XD-img-1_1771185526000_na1fn_cG9rZW1vbi1zcGFya2tsZS1iZy1ob21lLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MA')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Header */}
      <div className="bg-black/40 backdrop-blur-md border-b border-yellow-400/30 sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <img
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663354566707/zzikNLpXwcKjiPKc.png"
                alt="Poke Card Scanner"
                className="w-8 h-8"
              />
              <div>
                <h1 className="text-2xl font-bold text-yellow-300">
                  Poke Card Scanner
                </h1>
                <p className="text-xs text-yellow-200">
                  Ciao, {user.name || "Utente"}!
                </p>
              </div>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="p-2 hover:bg-yellow-400/20 rounded-lg transition-colors"
            title="Esci"
          >
            <LogOut className="w-5 h-5 text-yellow-300" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col p-4 max-w-md mx-auto w-full">
        {/* Quick Actions */}
        <div className="mt-6 space-y-3">
          <Button
            onClick={() => setLocation("/scan")}
            size="lg"
            className="w-full gap-2 bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-semibold shadow-lg transform hover:scale-105 transition-all duration-300"
          >
            <Camera className="w-5 h-5" />
            Scansiona Nuova Carta
          </Button>

          <Button
            onClick={() => setLocation("/history")}
            variant="outline"
            size="lg"
            className="w-full gap-2 bg-white/10 hover:bg-white/20 text-yellow-300 border-yellow-400/50 backdrop-blur-md transform hover:scale-105 transition-all duration-300"
          >
            <History className="w-5 h-5" />
            Visualizza Storico
          </Button>
        </div>

        {/* Stats Section */}
        <div className="mt-8 grid grid-cols-2 gap-4">
          <div className="bg-white/10 backdrop-blur-md rounded-lg p-4 border border-yellow-400/30">
            <p className="text-xs text-yellow-200 mb-1">Carte Scansionate</p>
            <p className="text-2xl font-bold text-yellow-300">0</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-lg p-4 border border-yellow-400/30">
            <p className="text-xs text-yellow-200 mb-1">Valore Totale</p>
            <p className="text-2xl font-bold text-yellow-300">$0</p>
          </div>
        </div>

        {/* Info Card */}
        <div className="mt-8 bg-gradient-to-br from-yellow-400/20 to-yellow-300/10 rounded-lg p-6 border border-yellow-400/50 backdrop-blur-md">
          <h3 className="font-semibold text-yellow-300 mb-2">Come Funziona</h3>
          <ol className="text-sm text-yellow-100 space-y-2">
            <li>
              <strong>1.</strong> Accedi alla fotocamera
            </li>
            <li>
              <strong>2.</strong> Inquadra una carta Pokémon
            </li>
            <li>
              <strong>3.</strong> Visualizza i dati e il prezzo
            </li>
            <li>
              <strong>4.</strong> Salva nello storico personale
            </li>
          </ol>
        </div>
      </div>
    </div>
  );
}
