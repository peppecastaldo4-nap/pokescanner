import { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Camera, Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface CameraScannerProps {
  onCapture: (imageData: Blob) => void;
  isProcessing?: boolean;
}

export function CameraScanner({ onCapture, isProcessing = false }: CameraScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const retryCountRef = useRef(0);

  // Initialize camera with retry logic
  useEffect(() => {
    let isMounted = true;

    const initCamera = async () => {
      try {
        setIsInitializing(true);
        setCameraError(null);
        setPermissionDenied(false);

        // Add a timeout to prevent infinite loading
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Camera initialization timeout")), 5000)
        );

        const cameraPromise = navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "environment", // Back camera for mobile
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
        });

        const stream = await Promise.race([cameraPromise, timeoutPromise]) as MediaStream;

        if (isMounted && videoRef.current) {
          videoRef.current.srcObject = stream;
          setCameraActive(true);
          setIsInitializing(false);
          retryCountRef.current = 0;
        }
      } catch (error) {
        if (!isMounted) return;

        if (error instanceof DOMException && error.name === "NotAllowedError") {
          setPermissionDenied(true);
          setCameraError("Permesso fotocamera negato. Abilita l'accesso alla fotocamera nelle impostazioni.");
        } else if (error instanceof DOMException && error.name === "NotFoundError") {
          setCameraError("Nessuna fotocamera disponibile su questo dispositivo.");
        } else if (error instanceof Error && error.message.includes("timeout")) {
          setCameraError("Timeout nell'accesso alla fotocamera. Riprova.");
        } else {
          setCameraError("Errore nell'accesso alla fotocamera. Riprova.");
        }
        setCameraActive(false);
        setIsInitializing(false);
      }
    };

    initCamera();

    return () => {
      isMounted = false;
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const handleCapture = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    if (!ctx) return;

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw video frame to canvas
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Convert canvas to blob and send
    canvas.toBlob((blob) => {
      if (blob) {
        onCapture(blob);
      }
    }, "image/jpeg", 0.9);
  };

  const handleRetry = async () => {
    retryCountRef.current += 1;
    setCameraError(null);
    setPermissionDenied(false);
    setIsInitializing(true);

    try {
      // Add timeout
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Camera initialization timeout")), 5000)
      );

      const cameraPromise = navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment",
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      const stream = await Promise.race([cameraPromise, timeoutPromise]) as MediaStream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
        setIsInitializing(false);
      }
    } catch (error) {
      setIsInitializing(false);
      if (error instanceof DOMException && error.name === "NotAllowedError") {
        setPermissionDenied(true);
        setCameraError("Permesso fotocamera negato. Abilita l'accesso nelle impostazioni.");
      } else if (error instanceof Error && error.message.includes("timeout")) {
        setCameraError("Timeout nell'accesso alla fotocamera. Riprova.");
      } else {
        setCameraError("Errore nell'accesso alla fotocamera. Riprova.");
      }
    }
  };

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Camera Feed */}
      <div className="relative w-full bg-black rounded-lg overflow-hidden aspect-video">
        {cameraActive ? (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
            {/* Camera frame overlay */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 border-2 border-yellow-400 opacity-50" />
              <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 border-2 border-yellow-400 rounded-lg opacity-75" />
            </div>
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gray-900">
            <div className="text-center">
              {cameraError ? (
                <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-2" />
              ) : (
                <Camera className="w-12 h-12 text-gray-400 mx-auto mb-2 animate-pulse" />
              )}
              <p className="text-gray-400 text-sm">
                {cameraError ? "Errore fotocamera" : isInitializing ? "Inizializzazione fotocamera..." : "Fotocamera non disponibile"}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Error Alert */}
      {cameraError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{cameraError}</AlertDescription>
        </Alert>
      )}

      {/* Permission Denied Alert */}
      {permissionDenied && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Per usare la fotocamera, abilita il permesso nelle impostazioni del browser e riprova.
          </AlertDescription>
        </Alert>
      )}

      {/* Capture Button */}
      <Button
        onClick={handleCapture}
        disabled={!cameraActive || isProcessing}
        size="lg"
        className="w-full gap-2"
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Elaborazione...
          </>
        ) : (
          <>
            <Camera className="w-4 h-4" />
            Scatta Foto
          </>
        )}
      </Button>

      {/* Retry Button */}
      {(cameraError || (isInitializing && retryCountRef.current > 0)) && (
        <Button
          onClick={handleRetry}
          variant="outline"
          className="w-full"
          disabled={isInitializing}
        >
          {isInitializing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
              Riprova in corso...
            </>
          ) : (
            "Riprova"
          )}
        </Button>
      )}

      {/* Hidden Canvas for capture */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
