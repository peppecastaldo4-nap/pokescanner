# Poke Card Scanner - Project TODO

## Database & Backend
- [x] Schema database: tabelle per utenti, carte scansionate, storico scansioni
- [x] Integrazione Pokémon TCG API per ricerca carte
- [x] Procedure tRPC per scansioni CRUD e recupero dati carte
- [x] Logica di calcolo prezzo consigliato basato su trend di mercato

## Frontend - Interfaccia Scansione
- [x] Pagina di scansione mobile-first con accesso fotocamera
- [x] Componente camera feed con preview in tempo reale
- [x] Pulsante di cattura foto e gestione permessi fotocamera
- [x] Indicatori di caricamento durante il riconoscimento

## Frontend - Riconoscimento e Integrazione API
- [x] Integrazione servizio riconoscimento immagini (Gemini Vision)
- [x] Parsing risultati e ricerca carta su Pokémon TCG API
- [x] Gestione errori per carte non riconosciute

## Frontend - Visualizzazione Dati
- [x] Pagina dettagli carta con immagine, nome, codice, rarità
- [x] Visualizzazione prezzo di mercato (TCGPlayer market price)
- [x] Calcolo e display prezzo consigliato per vendita
- [x] Pulsante per salvare carta nello storico

## Frontend - Storico e Dashboard
- [x] Pagina storico scansioni con lista carte salvate
- [x] Visualizzazione statistiche personali (carte scansionate, valore totale)
- [x] Funzione di eliminazione dal storico
- [x] Ricerca e filtri nel storico

## Frontend - Design & UX
- [x] Design mobile-first ottimizzato per smartphone
- [x] Layout responsivo per tablet (fallback)
- [x] Navigazione intuitiva tra scansione, dettagli e storico
- [x] Indicatori di stato e feedback visivi

## Testing & Deployment
- [x] Unit test per logica di calcolo prezzi
- [x] Test integrazione API Pokémon TCG (API key aggiunta e testata)
- [x] Test responsivo mobile (design ottimizzato)
- [x] Logo app con P e C multicolor e bordo argento
- [x] Integrazione Google AdSense per monetizzazione
- [x] Aggiornamento nome app a "Poke Card Scanner"
- [x] Aggiunta API Key Pokémon TCG
- [x] App pubblicata online e funzionante
- [ ] Collegamento dominio pokescanner.it (lunedì)
- [ ] Aggiunta Publisher ID Google AdSense (lunedì)
