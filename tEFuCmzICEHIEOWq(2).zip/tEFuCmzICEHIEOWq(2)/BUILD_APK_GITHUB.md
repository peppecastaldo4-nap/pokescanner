# Compilazione APK con GitHub Actions

Questa guida ti spiega come compilare l'APK di Poke Card Scanner usando GitHub Actions direttamente dal tuo smartphone.

## 📱 Istruzioni Passo-Passo

### 1. Accedi a GitHub
- Apri il browser del tuo Motorola G86 5G
- Vai su: https://github.com/login
- Accedi con il tuo account GitHub (o creane uno se non lo hai)

### 2. Vai al Repository
- Una volta loggato, vai a: https://github.com/[username]/pokescanner
- Sostituisci `[username]` con il tuo username GitHub

### 3. Avvia la Compilazione
- Clicca sulla scheda **"Actions"** in alto
- Clicca su **"Build APK"** nella lista a sinistra
- Clicca il pulsante **"Run workflow"** (a destra)
- Seleziona **"debug"** come build type
- Clicca **"Run workflow"**

### 4. Aspetta la Compilazione
- La compilazione inizierà automaticamente
- Ci vorranno circa 10-15 minuti
- Puoi vedere il progresso nella pagina

### 5. Scarica l'APK
- Una volta completata la compilazione (vedrai un ✅ verde)
- Clicca sul job completato
- Scorri fino a "Artifacts"
- Clicca su **"app-debug.apk"** per scaricare il file

### 6. Installa l'APK
- Una volta scaricato, apri il file manager
- Cerca il file **"app-debug.apk"** nella cartella Download
- Clicca su di esso per installare l'app
- Consenti i permessi richiesti
- L'app si installerà automaticamente

### 7. Testa l'App
- Apri l'app "Poke Card Scanner"
- Accedi con il tuo account
- Clicca "Scansiona Nuova Carta"
- La fotocamera dovrebbe funzionare perfettamente! 📸

## ⚠️ Problemi Comuni

### "Installazione bloccata"
- Vai in Impostazioni → Sicurezza
- Abilita "Installa da fonti sconosciute"
- Riprova a installare l'APK

### "File non trovato"
- Assicurati che il download sia completato
- Controlla la cartella Download del tuo telefono

### "La compilazione fallisce"
- Aspetta 5 minuti e riprova
- Se continua a fallire, contattami

## 🎉 Fatto!
Congratulazioni! Ora hai l'app nativa sul tuo telefono con accesso completo alla fotocamera!

---

**Nota:** Questo APK è una versione di debug. Per pubblicare su Google Play Store, avremo bisogno di una versione firmata (release).
