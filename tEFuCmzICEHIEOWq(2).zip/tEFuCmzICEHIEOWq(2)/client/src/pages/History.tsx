import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Trash2, Loader2, Search } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { AdBanner } from "@/components/AdBanner";

interface SavedCard {
  id: number;
  cardName: string;
  cardCode: string;
  rarity?: string;
  marketPrice?: number;
  suggestedSellingPrice?: number;
  imageUrl?: string;
  scannedAt: string;
}

export default function History() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [cards, setCards] = useState<SavedCard[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [deletingId, setDeletingId] = useState<number | null>(null);

  useEffect(() => {
    const fetchHistory = async () => {
      if (!user) return;

      try {
        setIsLoading(true);
        // Call backend to fetch user's scanned cards
        const response = await fetch("/api/trpc/cards.getUserCards", {
          method: "GET",
        });

        if (!response.ok) {
          throw new Error("Errore nel caricamento dello storico");
        }

        const data = await response.json();
        setCards(data.result || []);
      } catch (error) {
        console.error("Fetch error:", error);
        toast.error("Errore nel caricamento dello storico");
      } finally {
        setIsLoading(false);
      }
    };

    fetchHistory();
  }, [user]);

  const handleDelete = async (cardId: number) => {
    try {
      setDeletingId(cardId);
      const response = await fetch("/api/trpc/cards.deleteCard", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ cardId }),
      });

      if (!response.ok) {
        throw new Error("Errore nell'eliminazione");
      }

      setCards(cards.filter((c) => c.id !== cardId));
      toast.success("Carta eliminata");
    } catch (error) {
      console.error("Delete error:", error);
      toast.error("Errore nell'eliminazione della carta");
    } finally {
      setDeletingId(null);
    }
  };

  const filteredCards = cards.filter((card) =>
    card.cardName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    card.cardCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalValue = filteredCards.reduce((sum, card) => sum + (card.marketPrice || 0), 0);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-b from-slate-900 to-slate-800">
        <p className="text-center text-yellow-300">Effettua il login per visualizzare lo storico.</p>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        backgroundImage:
          "url('https://private-us-east-1.manuscdn.com/sessionFile/W4oNi9bUr7vrHe7xFDd2hQ/sandbox/qS21jHqU9wn9upQdVF3Ti0-img-1_1771185565000_na1fn_cG9rZW1vbi1zcGFya2tsZS1iZy1oaXN0b3J5LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MA')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Header */}
      <div className="bg-black/40 backdrop-blur-md border-b border-yellow-400/30 sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-yellow-400/20 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-yellow-300" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-yellow-300">Storico Scansioni</h1>
            <p className="text-xs text-yellow-200">{cards.length} carte salvate</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col p-4 max-w-md mx-auto w-full py-6">
        {/* Stats */}
        {cards.length > 0 && (
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card className="bg-white/10 backdrop-blur-md border-yellow-400/30">
              <CardContent className="pt-6">
                <p className="text-xs text-yellow-200 mb-1">Carte Salvate</p>
                <p className="text-2xl font-bold text-yellow-300">{cards.length}</p>
              </CardContent>
            </Card>
            <Card className="bg-white/10 backdrop-blur-md border-yellow-400/30">
              <CardContent className="pt-6">
                <p className="text-xs text-yellow-200 mb-1">Valore Totale</p>
                <p className="text-2xl font-bold text-yellow-300">${totalValue.toFixed(2)}</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Ad Banner */}
        <div className="mb-6">
          <AdBanner slot="1234567890" format="horizontal" className="flex justify-center" />
        </div>

        {/* Search */}
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-3 w-4 h-4 text-yellow-300" />
          <Input
            placeholder="Cerca per nome o codice..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/10 backdrop-blur-md border-yellow-400/30 text-yellow-100 placeholder-yellow-300/50"
          />
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-yellow-300" />
          </div>
        )}

        {/* Empty State */}
        {!isLoading && cards.length === 0 && (
          <div className="text-center py-12">
            <p className="text-yellow-200 mb-4">Nessuna carta scansionata ancora</p>
            <Button
              onClick={() => setLocation("/scan")}
              className="gap-2 bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-semibold"
            >
              Scansiona la Prima Carta
            </Button>
          </div>
        )}

        {/* No Results */}
        {!isLoading && cards.length > 0 && filteredCards.length === 0 && (
          <div className="text-center py-8">
            <p className="text-yellow-200">Nessuna carta corrisponde alla ricerca</p>
          </div>
        )}

        {/* Cards List */}
        {!isLoading && filteredCards.length > 0 && (
          <div className="space-y-3">
            {filteredCards.map((card) => (
              <Card
                key={card.id}
                className="overflow-hidden hover:shadow-md transition-all duration-300 transform hover:scale-105 bg-white/10 backdrop-blur-md border-yellow-400/30"
              >
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    {/* Card Image Thumbnail */}
                    {card.imageUrl && (
                      <div className="w-16 h-24 flex-shrink-0 rounded-lg overflow-hidden bg-slate-200">
                        <img
                          src={card.imageUrl}
                          alt={card.cardName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {/* Card Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-yellow-300 truncate">{card.cardName}</h3>
                      <p className="text-xs text-yellow-200 mb-2">{card.cardCode}</p>

                      {card.rarity && (
                        <p className="text-xs text-yellow-200 mb-2">
                          <span className="font-medium">Rarità:</span> {card.rarity}
                        </p>
                      )}

                      {card.marketPrice && (
                        <div className="flex items-baseline gap-2">
                          <p className="text-sm font-bold text-yellow-300">
                            ${card.marketPrice.toFixed(2)}
                          </p>
                          {card.suggestedSellingPrice && (
                            <p className="text-xs text-green-300 font-medium">
                              Vendi: ${card.suggestedSellingPrice.toFixed(2)}
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Delete Button */}
                    <button
                      onClick={() => handleDelete(card.id)}
                      disabled={deletingId === card.id}
                      className="p-2 text-yellow-300 hover:text-red-400 hover:bg-red-400/20 rounded-lg transition-colors flex-shrink-0"
                      title="Elimina"
                    >
                      {deletingId === card.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
