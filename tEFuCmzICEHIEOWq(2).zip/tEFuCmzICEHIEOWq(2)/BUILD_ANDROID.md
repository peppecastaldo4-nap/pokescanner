# Come Compilare l'App Android di Poke Card Scanner

## Prerequisiti

1. **Java Development Kit (JDK) 17+**
   ```bash
   java -version
   ```

2. **Android SDK**
   - Scarica Android Studio: https://developer.android.com/studio
   - Installa Android SDK Platform 34+

3. **Gradle** (incluso in Android Studio)

## Compilazione

### Step 1: Aggiornare i file web
```bash
pnpm build
cp -r dist/public www
npx cap sync
```

### Step 2: Aprire il progetto in Android Studio
```bash
cd android
# Oppure apri direttamente la cartella "android" in Android Studio
```

### Step 3: Compilare l'APK
1. In Android Studio: **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. Oppure da terminale:
   ```bash
   cd android
   ./gradlew assembleRelease
   ```

### Step 4: Firmare l'APK
```bash
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
  -keystore my-release-key.jks \
  app/build/outputs/apk/release/app-release-unsigned.apk \
  alias_name

zipalign -v 4 app-release-unsigned.apk app-release-signed.apk
```

### Step 5: Caricare su Google Play Store
1. Vai a: https://play.google.com/console
2. Crea un nuovo progetto
3. Carica l'APK firmato
4. Compila i dettagli dell'app (descrizione, screenshot, categoria)
5. Invia per la revisione

## Permessi Richiesti

L'app richiede i seguenti permessi (già configurati):
- `CAMERA` - Per scansionare le carte
- `INTERNET` - Per comunicare con i server
- `RECORD_AUDIO` - Per il microfono (se necessario)

## Icona e Splash Screen

Sostituisci le icone in:
- `android/app/src/main/res/mipmap-*/ic_launcher.png` (icona app)
- `android/app/src/main/res/drawable/splash.png` (splash screen)

## Firma dell'App

Per creare una chiave di firma:
```bash
keytool -genkey -v -keystore my-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias alias_name
```

## Note Importanti

- L'app accede alla fotocamera del dispositivo per scansionare le carte
- I dati vengono salvati nel database personale dell'utente
- L'app richiede connessione internet per il riconoscimento delle carte e i prezzi
- Mantieni la chiave di firma al sicuro - la userai per aggiornamenti futuri

## Supporto

Per problemi di compilazione, consulta:
- https://capacitorjs.com/docs/android
- https://developer.android.com/studio/build
