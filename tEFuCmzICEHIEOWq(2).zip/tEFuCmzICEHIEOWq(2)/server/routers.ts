import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { saveScannedCard, getUserScannedCards, getScannedCardById, deleteScannedCard, saveScanHistory } from "./db";
import { invokeLLM } from "./_core/llm";
import type { ImageContent, TextContent } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  cards: router({
    recognizeCard: protectedProcedure
      .input(z.object({
        image: z.string().describe("Base64 encoded image data"),
      }))
      .mutation(async ({ input, ctx }) => {
        try {
          const textMsg: TextContent = {
            type: "text",
            text: "Identify this Pokemon card:",
          };

          const imageMsg: ImageContent = {
            type: "image_url",
            image_url: {
              url: input.image,
            },
          };

          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: `You are an expert at identifying Pokemon Trading Card Game (TCG) cards. 
                Extract: card name, card code (set-number), rarity, set name.
                Respond with ONLY valid JSON: {"cardName": "string", "cardCode": "string", "rarity": "string or null", "setName": "string or null", "confidence": "high|medium|low"}
                If cannot identify: {"cardName": null, "confidence": "low"}`,
              },
              {
                role: "user",
                content: ([textMsg, imageMsg] as any) as string,
              },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "pokemon_card_recognition",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    cardName: { type: ["string", "null"] },
                    cardCode: { type: ["string", "null"] },
                    rarity: { type: ["string", "null"] },
                    setName: { type: ["string", "null"] },
                    confidence: { type: "string", enum: ["high", "medium", "low"] },
                  },
                  required: ["cardName", "confidence"],
                },
              },
            },
          });

          const content = response.choices[0]?.message?.content;
          if (!content) {
            throw new Error("No response from LLM");
          }

          const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
          const recognitionResult = JSON.parse(contentStr);

          await saveScanHistory({
            userId: ctx.user.id,
            imageUrl: input.image,
            recognitionStatus: recognitionResult.cardName ? "success" : "failed",
            recognitionResult,
          });

          if (!recognitionResult.cardName) {
            return {
              success: false,
              message: "Carta non riconosciuta",
            };
          }

          const tcgResponse = await fetch(
            `https://api.pokemontcg.io/v2/cards?q=name:"${recognitionResult.cardName}"`,
            {
              headers: {
                "X-Api-Key": process.env.POKEMON_TCG_API_KEY || "",
              },
            }
          );

          if (!tcgResponse.ok) {
            throw new Error("Failed to fetch from Pokemon TCG API");
          }

          const tcgData = await tcgResponse.json();

          if (!tcgData.data || tcgData.data.length === 0) {
            return {
              success: false,
              message: "Carta non trovata nel database TCG",
            };
          }

          const card = tcgData.data[0];
          const tcgplayerPrices = card.tcgplayer?.prices || {};
          const marketPrice = tcgplayerPrices.holofoil?.market || 
                             tcgplayerPrices.normal?.market || 
                             tcgplayerPrices.reverseHolofoil?.market || 
                             0;

          const suggestedSellingPrice = marketPrice * 0.85;

          return {
            success: true,
            cardId: card.id,
            cardName: card.name,
            cardCode: `${card.set.id}-${card.number}`,
            rarity: card.rarity,
            setName: card.set.name,
            setId: card.set.id,
            imageUrl: card.images?.large,
            marketPrice: parseFloat(marketPrice.toFixed(2)),
            lowPrice: parseFloat((tcgplayerPrices.holofoil?.low || 0).toFixed(2)),
            highPrice: parseFloat((tcgplayerPrices.holofoil?.high || 0).toFixed(2)),
            midPrice: parseFloat((tcgplayerPrices.holofoil?.mid || 0).toFixed(2)),
            suggestedSellingPrice: parseFloat(suggestedSellingPrice.toFixed(2)),
            tcgplayerData: card.tcgplayer,
          };
        } catch (error) {
          console.error("Card recognition error:", error);
          throw new Error("Errore nel riconoscimento della carta");
        }
      }),

    saveCard: protectedProcedure
      .input(z.object({
        cardId: z.string(),
        cardName: z.string(),
        cardCode: z.string(),
        rarity: z.string().optional(),
        setName: z.string().optional(),
        setId: z.string().optional(),
        imageUrl: z.string().optional(),
        marketPrice: z.number().optional(),
        lowPrice: z.number().optional(),
        highPrice: z.number().optional(),
        midPrice: z.number().optional(),
        suggestedSellingPrice: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const card = await saveScannedCard({
          userId: ctx.user.id,
          cardId: input.cardId,
          cardName: input.cardName,
          cardCode: input.cardCode,
          rarity: input.rarity,
          setName: input.setName,
          setId: input.setId,
          imageUrl: input.imageUrl,
          marketPrice: input.marketPrice ? String(parseFloat(input.marketPrice.toFixed(2))) : null,
          lowPrice: input.lowPrice ? String(parseFloat(input.lowPrice.toFixed(2))) : null,
          highPrice: input.highPrice ? String(parseFloat(input.highPrice.toFixed(2))) : null,
          midPrice: input.midPrice ? String(parseFloat(input.midPrice.toFixed(2))) : null,
          suggestedSellingPrice: input.suggestedSellingPrice ? String(parseFloat(input.suggestedSellingPrice.toFixed(2))) : null,
          tcgplayerData: null,
        });

        return {
          success: true,
          card,
        };
      }),

    getUserCards: protectedProcedure
      .input(z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      }).optional())
      .query(async ({ input, ctx }) => {
        const cards = await getUserScannedCards(
          ctx.user.id,
          input?.limit || 50,
          input?.offset || 0
        );
        return cards;
      }),

    getCard: protectedProcedure
      .input(z.object({
        cardId: z.number(),
      }))
      .query(async ({ input, ctx }) => {
        const card = await getScannedCardById(input.cardId, ctx.user.id);
        return card;
      }),

    deleteCard: protectedProcedure
      .input(z.object({
        cardId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        const success = await deleteScannedCard(input.cardId, ctx.user.id);
        return { success };
      }),
  }),
});

export type AppRouter = typeof appRouter;
