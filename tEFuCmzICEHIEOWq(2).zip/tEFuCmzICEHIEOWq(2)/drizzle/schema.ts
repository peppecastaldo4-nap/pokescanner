import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Table for storing scanned Pokémon cards
 */
export const scannedCards = mysqlTable("scanned_cards", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  cardId: varchar("cardId", { length: 64 }).notNull(), // Pokémon TCG API card ID
  cardName: varchar("cardName", { length: 255 }).notNull(),
  cardCode: varchar("cardCode", { length: 64 }).notNull(), // Set code + card number (e.g., "sv04.5-1")
  rarity: varchar("rarity", { length: 64 }),
  setName: varchar("setName", { length: 255 }),
  setId: varchar("setId", { length: 64 }),
  imageUrl: text("imageUrl"),
  // Price data from TCGPlayer
  marketPrice: decimal("marketPrice", { precision: 10, scale: 2 }),
  lowPrice: decimal("lowPrice", { precision: 10, scale: 2 }),
  highPrice: decimal("highPrice", { precision: 10, scale: 2 }),
  midPrice: decimal("midPrice", { precision: 10, scale: 2 }),
  // Suggested selling price (calculated)
  suggestedSellingPrice: decimal("suggestedSellingPrice", { precision: 10, scale: 2 }),
  // Raw API response for reference
  tcgplayerData: json("tcgplayerData"),
  // Metadata
  scannedAt: timestamp("scannedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ScannedCard = typeof scannedCards.$inferSelect;
export type InsertScannedCard = typeof scannedCards.$inferInsert;

/**
 * Table for storing scan history with image references
 */
export const scanHistory = mysqlTable("scan_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  scannedCardId: int("scannedCardId"),
  imageUrl: text("imageUrl"), // URL of the captured photo
  recognitionStatus: mysqlEnum("recognitionStatus", ["success", "failed", "partial"]).notNull(),
  recognitionResult: json("recognitionResult"), // Raw result from recognition service
  errorMessage: text("errorMessage"),
  scannedAt: timestamp("scannedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ScanHistory = typeof scanHistory.$inferSelect;
export type InsertScanHistory = typeof scanHistory.$inferInsert;
