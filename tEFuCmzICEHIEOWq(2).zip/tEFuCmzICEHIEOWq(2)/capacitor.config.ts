import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.pokescanner.app',
  appName: 'Poke Card Scanner',
  webDir: 'www'
};

export default config;
