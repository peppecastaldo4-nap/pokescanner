CREATE TABLE `scan_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`scannedCardId` int,
	`imageUrl` text,
	`recognitionStatus` enum('success','failed','partial') NOT NULL,
	`recognitionResult` json,
	`errorMessage` text,
	`scannedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `scan_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scanned_cards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`cardId` varchar(64) NOT NULL,
	`cardName` varchar(255) NOT NULL,
	`cardCode` varchar(64) NOT NULL,
	`rarity` varchar(64),
	`setName` varchar(255),
	`setId` varchar(64),
	`imageUrl` text,
	`marketPrice` decimal(10,2),
	`lowPrice` decimal(10,2),
	`highPrice` decimal(10,2),
	`midPrice` decimal(10,2),
	`suggestedSellingPrice` decimal(10,2),
	`tcgplayerData` json,
	`scannedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `scanned_cards_id` PRIMARY KEY(`id`)
);
