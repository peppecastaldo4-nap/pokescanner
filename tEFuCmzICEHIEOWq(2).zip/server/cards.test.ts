import { describe, it, expect } from "vitest";

/**
 * Test per la logica di calcolo del prezzo consigliato
 */
describe("Card Pricing Logic", () => {
  it("should calculate suggested selling price as 85% of market price", () => {
    const marketPrice = 100;
    const suggestedSellingPrice = marketPrice * 0.85;
    
    expect(suggestedSellingPrice).toBe(85);
  });

  it("should handle decimal market prices correctly", () => {
    const marketPrice = 45.99;
    const suggestedSellingPrice = marketPrice * 0.85;
    
    expect(parseFloat(suggestedSellingPrice.toFixed(2))).toBe(39.09);
  });

  it("should handle zero market price", () => {
    const marketPrice = 0;
    const suggestedSellingPrice = marketPrice * 0.85;
    
    expect(suggestedSellingPrice).toBe(0);
  });

  it("should handle very high market prices", () => {
    const marketPrice = 5000;
    const suggestedSellingPrice = marketPrice * 0.85;
    
    expect(suggestedSellingPrice).toBe(4250);
  });

  it("should handle small market prices", () => {
    const marketPrice = 0.99;
    const suggestedSellingPrice = marketPrice * 0.85;
    
    expect(parseFloat(suggestedSellingPrice.toFixed(2))).toBe(0.84);
  });
});

/**
 * Test per la validazione dei dati della carta
 */
describe("Card Data Validation", () => {
  it("should validate card code format", () => {
    const cardCode = "sv04.5-1";
    const isValid = /^[a-z0-9]+\.[0-9]+-\d+$/.test(cardCode);
    
    expect(isValid).toBe(true);
  });

  it("should reject invalid card code format", () => {
    const cardCode = "invalid";
    const isValid = /^[a-z0-9]+\.[0-9]+-\d+$/.test(cardCode);
    
    expect(isValid).toBe(false);
  });

  it("should validate card name is not empty", () => {
    const cardName = "Pikachu";
    const isValid = cardName.trim().length > 0;
    
    expect(isValid).toBe(true);
  });

  it("should reject empty card name", () => {
    const cardName = "";
    const isValid = cardName.trim().length > 0;
    
    expect(isValid).toBe(false);
  });
});

/**
 * Test per la gestione dei prezzi da TCGPlayer
 */
describe("TCGPlayer Price Extraction", () => {
  it("should prioritize holofoil market price", () => {
    const tcgplayerPrices = {
      holofoil: { market: 50 },
      normal: { market: 30 },
      reverseHolofoil: { market: 40 },
    };
    
    const marketPrice = tcgplayerPrices.holofoil?.market || 
                       tcgplayerPrices.normal?.market || 
                       tcgplayerPrices.reverseHolofoil?.market || 
                       0;
    
    expect(marketPrice).toBe(50);
  });

  it("should fallback to normal price if holofoil unavailable", () => {
    const tcgplayerPrices = {
      normal: { market: 30 },
      reverseHolofoil: { market: 40 },
    };
    
    const marketPrice = tcgplayerPrices.holofoil?.market || 
                       tcgplayerPrices.normal?.market || 
                       tcgplayerPrices.reverseHolofoil?.market || 
                       0;
    
    expect(marketPrice).toBe(30);
  });

  it("should handle missing price data", () => {
    const tcgplayerPrices = {};
    
    const marketPrice = tcgplayerPrices.holofoil?.market || 
                       tcgplayerPrices.normal?.market || 
                       tcgplayerPrices.reverseHolofoil?.market || 
                       0;
    
    expect(marketPrice).toBe(0);
  });

  it("should extract all price types correctly", () => {
    const tcgplayerPrices = {
      holofoil: {
        low: 40,
        mid: 50,
        high: 60,
        market: 55,
      },
    };
    
    expect(tcgplayerPrices.holofoil.low).toBe(40);
    expect(tcgplayerPrices.holofoil.mid).toBe(50);
    expect(tcgplayerPrices.holofoil.high).toBe(60);
    expect(tcgplayerPrices.holofoil.market).toBe(55);
  });
});
