package com.pokescanner.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
